INSERT INTO users (username, firstname, lastname, role) VALUES
  ('admin', 'Foo', 'Bar', 1),
  ('hng', 'John', 'Doe', 0),
  ('user', 'Jane', 'Doe', 0);
